const getters = {
  rootRemToPx: state => state.rootRemToPx,
  user: state => state.user,
  home: state => state.home,
}
export default getters