<template>
  <div>
    page 404
  </div>
</template>
<script>
export default {
  name: 'login'
}
</script>