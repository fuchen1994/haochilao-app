<template>
  <div>
    page home
  </div>
</template>
<script>
export default {
  name: 'home'
}
</script>