const getters = {
  user: state => state.user
}
export default getters